import { Text, Image, StyleSheet, TouchableOpacity } from "react-native";

const ImageCard = ({ onPress, name, imageUrl }) => {
  return (
    <TouchableOpacity onPress={onPress} style={styles.container}>
      <Image style={styles.image} source={{ uri: imageUrl }} />
      <Text>{name}</Text>
    </TouchableOpacity>
  );
};

export default ImageCard;

const styles = StyleSheet.create({
  container: { marginBottom: 15 },
  image: {
    width: 150,
    height: 150,
  },
});
