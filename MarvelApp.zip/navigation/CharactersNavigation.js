import { createNativeStackNavigator } from "@react-navigation/native-stack";
import CharacterScreen from "../screens/CharacterScreen";
import DetailScreen from "../screens/DetailScreen";
import HomeScreen from "../screens/HomeScreen";

const CharactersStack = createNativeStackNavigator();

const CharactersNavigation = () => (
  <CharactersStack.Navigator>
    <CharactersStack.Screen name="Home" component={HomeScreen} />
    <CharactersStack.Screen name="Detail" component={CharacterScreen} />
  </CharactersStack.Navigator>
);

export default CharactersNavigation;
