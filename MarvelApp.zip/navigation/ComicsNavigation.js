import { createNativeStackNavigator } from "@react-navigation/native-stack";
import ComicsScreen from "../screens/ComicsScreen";
import DetailScreen from "../screens/DetailScreen";

const ComicsStack = createNativeStackNavigator();

const ComicsNavigation = () => (
  <ComicsStack.Navigator>
    <ComicsStack.Screen name="Home" component={ComicsScreen} />
    <ComicsStack.Screen name="Detail" component={DetailScreen} />
  </ComicsStack.Navigator>
);

export default ComicsNavigation;
