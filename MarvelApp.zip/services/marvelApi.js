import { API_KEY, API_PRIVATE } from "@env";
import md5 from "md5";

const URL = "https://gateway.marvel.com:443/v1/public";

export const getMarvelCharacters = () => {
  const ts = new Date().getTime();
  const hash = md5(`${ts}${API_PRIVATE}${API_KEY}`);

  return fetch(`${URL}/characters?ts=${ts}&apikey=${API_KEY}&hash=${hash}`)
    .then((res) => res.json())
    .then((json) => json);
};

export const getMarvelComics = () => {
  const ts = new Date().getTime();
  const hash = md5(`${ts}${API_PRIVATE}${API_KEY}`);

  return fetch(`${URL}/comics?ts=${ts}&apikey=${API_KEY}&hash=${hash}`)
    .then((res) => res.json())
    .then((json) => json);
};

export const getMarvelCharacterById = (characterId) => {
  const ts = new Date().getTime();
  const hash = md5(`${ts}${API_PRIVATE}${API_KEY}`);

  return fetch(
    `${URL}/characters/${characterId}?ts=${ts}&apikey=${API_KEY}&hash=${hash}`
  )
    .then((res) => res.json())
    .then((json) => json);
};

export const getMarvelComicById = (comicId) => {
  const ts = new Date().getTime();
  const hash = md5(`${ts}${API_PRIVATE}${API_KEY}`);

  return fetch(
    `${URL}/comics/${comicId}?ts=${ts}&apikey=${API_KEY}&hash=${hash}`
  )
    .then((res) => res.json())
    .then((json) => json);
};
