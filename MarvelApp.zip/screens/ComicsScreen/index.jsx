import * as React from "react";
import { View, ScrollView } from "react-native";
import ImageCard from "../../components/ImageCard";
import { getMarvelComics } from "../../services/marvelApi";

const ComicsScreen = (props) => {
  const [comics, setComics] = React.useState([]);
  const { navigation } = props;

  React.useEffect(() => {
    getMarvelComics().then(({ data: { results } }) => {
      setComics(results);
    });
  }, []);

  return (
    <View
      style={{
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        padding: 15,
      }}
    >
      <ScrollView>
        <View
          style={{
            flexDirection: "row",
            flexWrap: "wrap",
            justifyContent: "space-between",
          }}
        >
          {comics.map((_comic) => {
            const {
              id,
              title,
              thumbnail: { path, extension },
            } = _comic;

            return (
              <ImageCard
                onPress={() => navigation.navigate("Detail", { id })}
                key={id}
                name={title}
                imageUrl={`${path}.${extension}`}
              />
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
};

export default ComicsScreen;
