import * as React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import ImageCard from "../../components/ImageCard";
import { getMarvelCharacterById } from "../../services/marvelApi";

const CharacterScreen = ({
  navigation,
  route: {
    params: { id },
  },
}) => {
  const [character, setCharacter] = React.useState({});

  React.useEffect(() => {
    getMarvelCharacterById(id).then(({ data: { results } }) => {
      setCharacter(results[0]);
    });
  }, []);

  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <ImageCard
        onPress={() => navigation.goBack()}
        name={character.name}
        imageUrl={`${character?.thumbnail?.path}.${character?.thumbnail?.extension}`}
      />
    </View>
  );
};

export default CharacterScreen;
