import { useEffect, useState } from "react";
import { Text, View, TouchableOpacity, ScrollView } from "react-native";
import ImageCard from "../../components/ImageCard";
import { getMarvelCharacters } from "../../services/marvelApi";

const HomeScreen = (props) => {
  const [characters, setCharacters] = useState([]);
  const { navigation } = props;

  useEffect(() => {
    getMarvelCharacters().then(({ data: { results } }) => {
      setCharacters(results);
    });
  }, []);

  return (
    <View
      style={{
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        padding: 15,
      }}
    >
      <ScrollView>
        <View
          style={{
            flexDirection: "row",
            flexWrap: "wrap",
            justifyContent: "space-between",
          }}
        >
          {characters.map((_character) => {
            const {
              id,
              name,
              thumbnail: { path, extension },
            } = _character;

            return (
              <ImageCard
                onPress={() => navigation.navigate("Detail", { id })}
                key={id}
                name={name}
                imageUrl={`${path}.${extension}`}
              />
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
};

export default HomeScreen;
