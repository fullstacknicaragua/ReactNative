import * as React from "react";
import { View, Text, TouchableOpacity } from "react-native";

const DetailScreen = ({ navigation }) => {
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Text>Detail Screen with. Press to go back</Text>
      </TouchableOpacity>
    </View>
  );
};

export default DetailScreen;
